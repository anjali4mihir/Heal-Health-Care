<div class="full_width main_contentt mc_inner load-job">
    <div class="full_width main_contentt_padd">
        <div class="full_width searchby-truck-main my-ratings my-network">
        	
        	<h2 class="text-danger text-center">do not have an access</h2>

        </div>
    </div>
</div>

