<footer class="pt-100 pb-70">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-lg-4">
                <div class="footer-item">
                    <div class="footer-feedback"><a href="<?= base_url() ?>"><img src="<?php echo base_url(); ?>assets/img/logo-5.png" alt="logo"></a><?= $site_details->site_description; ?></div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="footer-item">
                    <div class="footer-quick">
                        <h3>Quick Links</h3>
                        <ul>
                            <li><a href="<?= base_url() . 'about-us'; ?>"><i class="icofont-long-arrow-right"></i> About us</a></li>
                            <li><a href="<?= base_url() . 'services'; ?>"><i class="icofont-long-arrow-right"></i> Services</a></li>
                            <li><a href="<?= base_url() . 'term-condition'; ?>"><i class="icofont-long-arrow-right"></i>T&C</a></li>
                            <li><a href="<?= base_url() . 'privacy-policy'; ?>"><i class="icofont-long-arrow-right"></i> Privacy Policy</a></li>
                            <li><a href="<?= base_url() . 'partners/login'; ?>"><i class="icofont-long-arrow-right"></i> Login</a></li>
                            <li><a href="<?= base_url() . 'contact-us'; ?>"><i class="icofont-long-arrow-right"></i> Contact us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="footer-item">
                    <div class="footer-quick">
                        <h3>Our Services</h3>
                        <ul><?php foreach ($services as $key => $value) { ?><li><a href="<?= base_url() . 'services/' . $value->slug ?>"><i class="icofont-long-arrow-right"></i> <?= $value->title; ?></a></li><?php } ?></ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="footer-item">
                    <div class="footer-contact">
                        <h3>Contact Us</h3>
                        <ul>
                            <li><i class="icofont-location-pin"></i><?= $site_details->address; ?></li>
                            <li><i class="icofont-ui-message"></i><a href="mailto:<?= $site_details->header_email ?>"><?= $site_details->header_email ?></a><a href="mailto:<?= $site_details->contact_email ?>"><?= $site_details->contact_email ?></a></li>
                            <li><i class="icofont-stock-mobile"></i><a href="tel:<?= $site_details->contact_no ?>">Call: <?= $site_details->contact_no ?></a><!-- <a href="tel:<?= $site_details->help_line ?>">Call:<?= $site_details->help_line ?></a> -->
                            </li>
                        </ul><?php foreach ($social_media as $key => $value) { ?><a href="<?= $value->link ?>"><i class="<?= $value->icon_class ?>" style="color: #ed1c24; font-size:36px;"></i></a><?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="copyright-area">
    <div class="container">
        <div class="copyright-item">
            <p>Copyright ©2021 <a href="<?php echo site_url(); ?>" target="_blank">
                    <font color="#fff">@</font>Heal
                </a> . All Rights Reserved</p>
        </div>
    </div>
</div>
<div class="offcanvas-overlay"></div>
<div id="offcanvas-mobile-menu" class="offcanvas offcanvas-mobile-menu">
    <div class="inner">
        <div class="border-bottom mb-3 pb-3 text-end"><button class="offcanvas-close">×</button></div>
        <div class="offcanvas-head mb-3">
            <div class="header-top-offcanvas">
                <p><i class="icofont-google-map"></i> <span>ADDRESS:</span> <?= $site_details->address; ?></p>
            </div>
        </div>
        <nav class="offcanvas-menu">
            <ul>
                <li><a href="<?= base_url() ?>"><span class="menu-text">Home</span></a></li>
                <li><a href="<?= base_url() . 'services'; ?>"><span class="menu-text">Services</span></a></li>
                <li><a href="<?= base_url() . 'about-us'; ?>">About</a></li>
                <li><a href="<?= base_url() . 'contact-us'; ?>">Contact Us</a></li>
            </ul>
        </nav>
        <div class="offcanvas-social my-4">
            <ul><?php foreach ($social_media as $key => $value) { ?><li><a href="<?= $value->link ?>"><i class="<?= $value->icon_class ?>"></i></a></li><?php } ?></ul>
        </div>
        <ul class="media-wrap">
            <li class="media media-list"><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><a href="<?= base_url() . 'my-dashboard' ?>" class="book-now-btn">My Dashboard</a><?php } else { ?><a href="<?= base_url() . 'partners/login' ?>" class="book-now-btn">Login</a><?php } ?></li>
            <li class="media media-list"><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><a href="<?= base_url() . 'partners/logout' ?>" class="book-now-btn">Logout</a><?php  } else { ?><a href="<?= base_url() . 'register' ?>" class="book-now-btn">join with Us</a><?php } ?></li>
            <li class="media media-list"><a href="<?= base_url() . 'securities' ?>" class="book-now-btn">Securities</a></li>
        </ul>
    </div>
</div>
<div class="scroll-to-top"><span class="icofont-rounded-up"></span></div>