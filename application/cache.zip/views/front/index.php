<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Heal – Health & Medical</title><?php $this->load->view('front/common_css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.0.0/magnific-popup.min.css" />
</head>

<body>
    <div class="wrapper home-default-wrapper"><?php $this->load->view('front/common_header'); ?><main class="main-content site-wrapper-reveal">
            <section class="hero-slider"><img src="assets/img/finalll.webp" alt="" title=""></section>
            <div class="about-area pt-100 pb-70">
                <div class="container">
                    <div class="row text">
                        <div class="col-lg-6 col-md-6">
                            <div class="about-item about-right"><img src="<?php echo base_url(); ?>assets/img/about-shape1.png" alt="About">
                                <h2><a href="<?= base_url() . 'about-us'; ?>" style="color:red;">About </a>Our <font color="#ed1c24">@</font>Heal</h2>
                                <p><?php echo $about_us->short_desc; ?></p><a href="<?= base_url() . 'about-us'; ?>">Know More</a>
                            </div>
                        </div><?php foreach ($youtube_video as $key => $value) {
                                    $temp = explode("v=", $value['link']); ?><div class="col-lg-6 col-md-6">
                                <div class="about-item">
                                    <div class="about-left"><a class="popup-youtube" href="<?= $value['link']; ?>"><img src="https://img.youtube.com/vi/<?= $temp[1]; ?>/maxresdefault.jpg" alt="demo"></a></div>
                                </div>
                            </div><?php } ?>
                    </div>
                </div>
            </div><?php $this->load->view('front/common_facts'); ?><?php if (count($features) > 0) { ?><section class="feature-section" data-bg-color="#fff">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title" data-aos="fade-up" data-aos-duration="1100">
                                <h2 class="title"><span>Our</span><b> <a href="<?= base_url() . 'services'; ?>" style="color:red;">Services</h2></a></b>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-xl-8">
                            <div class="row icon-box-style" data-aos="fade-up" data-aos-duration="1100"><?php foreach ($services as $key => $value) {
                                                                                                            $returnpath = $this->config->item('service_images_uploaded_path'); ?><div class="col-md-6">
                                        <div class="icon-box-item">
                                            <div class="icon"><img src="<?= $returnpath . $value->iconimg; ?>"></div>
                                            <div class="content"><a href="<?= base_url() . 'services/' . $value->slug ?>">
                                                    <h5 class="title"><?= $value->title ?></h5>
                                                </a>
                                                <p><?= $value->short_desc ?></p>
                                            </div>
                                        </div>
                                    </div><?php } ?></div>
                        </div>
                    </div>
                </div>
                <div class="thumb" data-aos="fade-left" data-aos-duration="1500"><img src="<?php echo base_url(); ?>assets/img/photos/doctor-01.webp" alt="hope-Image" /></div>
            </section><?php } ?><?php if (count($doctors) > 0) { ?><section class="team-area team-default-area" data-bg-color="#f3f3f3">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title text-center" data-aos="fade-up" data-aos-duration="1000">
                                <p>Meet Our Docots</p>
                                <h2 class="title"><span>Professional &</span> Enthusiastic</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swiper-container team-slider-container" data-aos="fade-up" data-aos-duration="1300">
                                <div class="swiper-wrapper team-slider"><?php foreach ($doctors as $key => $value) {
                                                                            $returnpath = $this->config->item('banner_images_uploaded_path'); ?><div class="swiper-slide team-member">
                                            <div class="thumb"><img src="<?= $returnpath . $value->file; ?>" alt="hope-HasTech" /></div>
                                            <div class="content">
                                                <div class="member-info">
                                                    <h4 class="name"><?= $value->name; ?></h4>
                                                    <p><?= $value->details; ?></p><a href="#/" class="btn-link">Read More</a>
                                                </div>
                                            </div>
                                        </div><?php } ?></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><?php } ?><div class="app-screenshot-area round_shape_one">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title_box">
                            <h2>We Welcome All Medical Professionals</h2>
                            <h3>Free Registration</h3>
                        </div>
                        <div class="round_box_new">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="doctor-side owl-carousel owl-theme">
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-1.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Doctor</h4>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-2.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Veterinary Doctor</h4>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-3.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Nurse</h4>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-4.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Physiotherapist</h4>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-5.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Pharmacy Store</h4>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-6.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Pathology Lab</h4>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="image_box1"><img src="<?php echo base_url(); ?>assets/img/icon-7.webp" alt="icon"></div>
                                            <div class="image_title_text1">
                                                <h4>Radio Diagnostic Center</h4>
                                                <div></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 text-center"><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><?php } else { ?><a href="<?= base_url() . 'register' ?>" class="book-now-btn screenshot_btn">join with Us</a><?php } ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="app-screenshot-area round_shape_two">
                <div class="container">
                    <h3>How it's work</h3>
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <div class="app-step owl-carousel owl-theme">
                                <div class="item">
                                    <div class="text-center screen-step"><a href="assets/img/Step-1-1.jpg"><img src="<?php echo base_url(); ?>assets/img/step1.webp" alt="Download Application"></a>
                                        <h4 class="serif" style="padding-top: 10px;">Step 1</h4>
                                        <p class="serif">Choose Account</p>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="text-center screen-step"><a href="assets/img/Step-2-2.png"><img src="<?php echo base_url(); ?>assets/img/step3.webp" alt="Download Application"></a>
                                        <h4 class="serif" style="padding-top: 10px;">Step 2</h4>
                                        <p class="serif">Sign UP/Login</p>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="text-center screen-step"><a href="assets/img/Step-3-3.png"><img src="<?php echo base_url(); ?>assets/img/step-8.png" alt="Download Application"></a>
                                        <h4 class="serif" style="padding-top: 10px;">Step 3</h4>
                                        <p class="serif">Choose Services</p>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="text-center screen-step"><a href="assets/img/Step-4-4.png"><img src="<?php echo base_url(); ?>assets/img/step-4.png" alt="Download Application"></a>
                                        <h4 class="serif" style="padding-top: 10px;">Step 4</h4>
                                        <p class="serif">Fill Up The Form</p>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="text-center screen-step"><a href="assets/img/Step-5-5.png"><img src="<?php echo base_url(); ?>assets/img/step5.png" alt="Download Application"></a>
                                        <h4 class="serif" style="padding-top: 10px;">Step 5</h4>
                                        <p class="serif">Get Nearest Services</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <section id="app-screenshot-area" class="ptb-120 app-screenshot-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="swiper-container screenshot" data-aos="fade-up" data-aos-duration="1300">
                                <img src="<?php echo base_url(); ?>assets/img/splash-1-s.webp" alt="demo" />
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="section-heading">
                                <h2>Download Our App in Google Play and Apple store</h2>
                                <div class="button-group store-buttons">
                                    <div class="row">
                                        <div class="col-md-6 pr-0"><a href="https://play.google.com/store/apps/details?id=com.atheal"><img src="<?php echo base_url(); ?>assets/img/playstore.webp" alt="demo" /></a></div>
                                        <div class="col-md-6"><a href="https://apps.apple.com/us/app/heal/id1582761953"><img src="<?php echo base_url(); ?>assets/img/apple-store.webp" alt="demo" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><?php if (count($testimonials) > 0) { ?><section class="testimonial-area testimonial-default-area bg-img" data-bg-img="<?php echo base_url(); ?>assets/img/photos/testimonial-bg1.jpg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section-title text-center" data-aos="fade-up" data-aos-duration="1000">
                                    <h2 class="title"><span>Our</span> Doctors</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="swiper-container testimonial-slider-container" data-aos="fade-up" data-aos-duration="1100">
                                    <div class="swiper-wrapper testimonial-slider"><?php foreach ($testimonials as $key => $value) {
                                                                                        $returnpath = $this->config->item('banner_images_uploaded_path'); ?>
                                            <div class="swiper-slide testimonial-item">
                                                <div class="thumb"><img src="<?= $returnpath . $value->file; ?>" alt="Image" /></div>
                                                <div class="client-content"><?= $value->details; ?></div>
                                                <div class="client-info">
                                                    <div class="desc">
                                                        <h4 class="name"><?= $value->name; ?></h4>
                                                        <p class="client-location"><?= $value->position; ?></p>
                                                    </div>
                                                </div>
                                            </div><?php } ?>
                                    </div>
                                    <div class="swiper-button-next"></div>
                                    <div class="swiper-button-prev"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section><?php } ?>
        </main><?php $this->load->view('front/common_footer'); ?><div class="offcanvas-overlay"></div>
        <div id="offcanvas-mobile-menu" class="offcanvas offcanvas-mobile-menu">
            <div class="inner">
                <div class="border-bottom mb-3 pb-3 text-end"><button class="offcanvas-close">×</button></div>
                <div class="offcanvas-head mb-3">
                    <div class="header-top-offcanvas">
                        <p><i class="icofont-google-map"></i><span>ADDRESS:</span> 568 Elizaberth Str, London, UK</p>
                    </div>
                </div>
                <nav class="offcanvas-menu">
                    <ul>
                        <li><a href="#"><span class="menu-text">Home</span></a></li>
                        <li><a href="#"><span class="menu-text">Services</span></a>
                            <ul class="offcanvas-submenu">
                                <li><a href="services.html">Service</a></li>
                                <li><a href="service-details.html">service details</a></li>
                            </ul>
                        </li>
                        <li><a href="about.html">about</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                    </ul>
                </nav>
                <div class="offcanvas-social my-4">
                    <ul>
                        <li><a href="#"><i class="icofont-twitter"></i></a></li>
                        <li><a href="#"><i class="icofont-facebook"></i></a></li>
                        <li><a href="#"><i class="icofont-instagram"></i></a></li>
                        <li><a href="#"><i class="icofont-rss-feed"></i></a></li>
                        <li><a href="#"><i class="icofont-play-alt-1"></i></a></li>
                    </ul>
                </div>
                <ul class="media-wrap">
                    <li class="media media-list"><a href="login.html" class="book-now-btn">Login</a></li>
                    <li class="media media-list"><a href="register.html" class="book-now-btn">join with Us</a></li>
                </ul>
            </div>
        </div>
        <div class="scroll-to-top"><span class="icofont-rounded-up"></span></div>
    </div><?php $this->load->view('front/common_js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.0.0/jquery.magnific-popup.min.js"></script>
    <!-- Meta Pixel Code -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '449985093366925');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=449985093366925&ev=PageView&noscript=1" /></noscript>
    <!-- End Meta Pixel Code -->
    <script>
        var element = "";
        var iframeSrc = "";
        $('.videoLink1, .videoLink2, .videoLink3')
            .magnificPopup({
                type: 'inline',
                midClick: true,
                callbacks: {
                    open: function() {
                        element = "#" + $(this).attr("id");
                        iframeSrc = $(element).find("iframe").eq(0).clone();
                        $(element).find("iframe").eq(0).attr('src', $(element).find("iframe").eq(0).attr(
                            'local-src'));
                        console.log(element);
                    },
                    close: function() {
                        $(element).find("iframe").remove();
                        $(element).append(iframeSrc);
                    }
                }
            });
    </script>
    <script>
        $('.app-step').each(function() { // the containers for all your galleries
            $(this).magnificPopup({
                delegate: 'a', // the selector for gallery item
                type: 'image',
                gallery: {
                    enabled: true
                }
            });
        });
    </script>
</body>

</html>