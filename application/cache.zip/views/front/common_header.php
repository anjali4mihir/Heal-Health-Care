<?php
$uri = $this->uri->segment(1);
$this->load->view('front/gtagbody');
?>

<div class="preloader-wrap">
    <div class="preloader"><span class="dot"></span>
        <div class="dots"><span></span><span></span><span></span></div>
    </div>
</div>
<header class="header">
    <div class="header-middle mobile-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="header-middle-content">
                        <div class="header-logo"><a href="<?= base_url() ?>"><?php $returnpath = $this->config->item('site_images_uploaded_path'); ?><img class="sticky-img" src="<?= $returnpath . $site_details->header_logo ?>" alt="Logo" /></a></div>
                        <h2 style="color:white;">Key For Health</h2>
                        <ul class="media-wrap d-none d-lg-flex">
                            <li class="media media-list"><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><a href="<?= base_url() . 'my-dashboard' ?>" class="book-now-btn">My Dashboard</a><?php } else { ?><a href="<?= base_url() . 'partners/login' ?>" class="book-now-btn">Login</a><?php } ?></li>
                            <li class="media media-list"><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><a href="<?= base_url() . 'partners/logout' ?>" class="book-now-btn">Logout</a><?php  } else { ?><a href="<?= base_url() . 'register' ?>" class="book-now-btn">join with Us</a><?php } ?></li>
                            <li class="media media-list"><a href="<?= base_url() . 'securities' ?>" class="book-now-btn">Securities</a></li>
                        </ul>
                        <div class="mobile-menu-toggle d-lg-none"><a href="#offcanvas-mobile-menu" class="offcanvas-toggle"><svg viewBox="0 0 800 600">
                                    <path d="M300,220 C300,220 520,220 540,220 C740,220 640,540 520,420 C440,340 300,200 300,200" id="top"></path>
                                    <path d="M300,320 L540,320" id="middle"></path>
                                    <path d="M300,210 C300,210 520,210 540,210 C740,210 640,530 520,410 C440,330 300,190 300,190" id="bottom" transform="translate(480, 320) scale(1, -1) translate(-480, -318)"></path>
                                </svg></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom d-none d-lg-block" style="background-color: #ed1c24 !important;">
        <div class="container">
            <div class="row row-cols-2">
                <div class="col">
                    <div class="d-flex flex-wrap align-items-center justify-content-between">
                        <ul class="main-menu">
                            <li class="<?php if ($uri == '') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() ?>">Home</a></li>
                            <li class="<?php if ($uri == 'services') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() . 'services'; ?>">Services</a></li>
                            <li class="<?php if ($uri == 'about-us') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() . 'about-us'; ?>">About</a></li>
                            <li class="<?php if ($uri == 'contact-us') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() . 'contact-us'; ?>">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col">
                    <ul class="social-links text-end mt-3"><?php foreach ($social_media as $key => $value) { ?><li><a href="<?= $value->link ?>"><i class="<?= $value->icon_class ?>"></i></a></li><?php } ?></ul>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom sticky-header d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex flex-wrap align-items-center justify-content-between"><a href="<?= base_url() ?>">
                            <div class="logo-1"><?php $returnpath = $this->config->item('site_images_uploaded_path'); ?><img class="sticky-img" src="<?= $returnpath . $site_details->header_logo ?>" alt="Logo" /></div>
                        </a>
                        <ul class="main-menu">
                            <li class="<?php if ($uri == '') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() ?>">Home</a></li>
                            <li class="<?php if ($uri == 'services') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() . 'services'; ?>">Services</a></li>
                            <li class="<?php if ($uri == 'about-us') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() . 'about-us'; ?>">About</a></li>
                            <li class="<?php if ($uri == 'contact-us') {
                                            echo "active";
                                        } ?>"><a class="main-menu-link" href="<?= base_url() . 'contact-us'; ?>">Contact</a></li>
                            <li><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><a href="<?= base_url() . 'my-dashboard' ?>" class="book-now-btn">My Dashboard</a><?php } else { ?><a href="<?= base_url() . 'partners/login' ?>" class="book-now-btn">Login</a><?php } ?></li>
                            <li><?php if (isset($_SESSION['useremail']) && !empty($_SESSION['useremail'])) { ?><a href="<?= base_url() . 'partners/logout' ?>" class="book-now-btn">Logout</a><?php  } else { ?><a href="<?= base_url() . 'register' ?>" class="book-now-btn">join with Us</a><?php } ?></li>
                            <li><a href="<?= base_url() . 'securities' ?>" class="book-now-btn">Securities</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>