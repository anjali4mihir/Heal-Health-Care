<script>
var base_url = '<?=base_url();?>';
</script>
<script src="<?=base_url()?>assets/js/modernizr.js"></script>
<script src="<?=base_url()?>assets/js/jquery-main.js"></script>
<script src="<?=base_url()?>assets/js/jquery-migrate.js"></script>
<script src="<?=base_url()?>assets/js/popper.min.js"></script>
<script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"
    integrity="sha256-xI/qyl9vpwWFOXz7+x/9WkG5j/SVnSw21viy8fWwbeE=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/plugincollection.js"></script>
<script src="<?=base_url()?>assets/js/numscroller-1.0.js"></script>
<script src="<?=base_url()?>assets/js/owl.carousel.js"></script>
<script src="<?=base_url()?>assets/js/custom.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.min.js"></script>
<script src="<?=base_url()?>assets/js/datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
<script type="text/javascript">
jQuery(".scr").click(function() {
    jQuery('html,body').animate({
            scrollTop: jQuery(".app-screenshot-area").offset().top
        },
        'slow');
    return false;
});
</script>
<script type="text/javascript">
window.$crisp = [];
window.CRISP_WEBSITE_ID = "bb86ebd2-6f2f-4dc8-b695-da56b43e3136";
(function() {
    d = document;
    s = d.createElement("script");
    s.src = "https://client.crisp.chat/l.js";
    s.async = 1;
    d.getElementsByTagName("head")[0].appendChild(s);
})();
</script>